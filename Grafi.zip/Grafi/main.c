#include <stdio.h>
#include <stdlib.h>
#include "Graph.h"
#include <time.h>
#include "List.h"

int main()
{
    srand(time(NULL));

    Graph A,AMOD2,AMOD3;
    A=randomGraph(5,2,4);
    printf("\nA= \n");
    printGraph(A);
    //printf("\nA2= \n");
  //  printGraph(AMOD2);
    //printf("\nA3= \n");
   // printGraph(AMOD3);
  //  B=randomGraph(5,2,4);
  //  printf("\nB= \n");
  //  printGraph(B);
  //  removeNode(A,3);
    //printf("\nA= \n");
    //printGraph(A);



    //RimuoviArchiPesiPari(&A);    // RIMOZIONE ARCHI PESI PARI


    CreaG1G2daG(&A,&AMOD2,&AMOD3);

}






