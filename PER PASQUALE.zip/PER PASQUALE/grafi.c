#include "grafi.h"

struct grafo* crea_grafo(int n){
	struct grafo* G; int i;
	G=(struct grafo*)malloc(sizeof(struct grafo));
	G->v=(struct nodo**)malloc(sizeof(struct nodo*)*n);
	G->nv=n;
	for(i=0;i<n;i++)
		G->v[i]=NULL;
	return G;
}

int empty_graph(struct grafo* G){
	return G==NULL;
}

void stampa_grafo(struct grafo* G){
	int ca=0, i; struct nodo* app;
	if(!empty_graph(G)){
		printf("IL GRAFO HA VERTICI %d", G->nv);
		printf("\n");
		for(i=0;i<G->nv;i++){
			printf("NODI ADIACENTI AL VERTICE %d", i);
			printf("\n");
			app=G->v[i];
			while(app!=NULL){
				printf("%d",app->key);
				printf("\n");
				ca++;
				app=app->next;
			}
		}
	}
	printf("IL GRAFO HA ARCHI %d", ca/2);
	printf("\n");
}

void aggiunta_arco(struct grafo* G,int u,int v){
	struct nodo* elem1, *elem2, *app;
	if(G!=NULL)
		if(u>=0&&v>=0&&u<G->nv&&v<G->nv&&u!=v){
			G->v[u]=inserimento_in_coda(G->v[u],v);
			G->v[v]=inserimento_in_coda(G->v[v],u);
		}
			
}

struct nodo* inserimento_in_coda(struct nodo* e, int key){
	if(e==NULL){
		struct nodo* elem;
		elem=(struct nodo*)malloc(sizeof(struct nodo));
		elem->key=key;
		elem->next=NULL;
		return elem;
	}
	if(e->key!=key)
	e->next=inserimento_in_coda(e->next,key);
	else{
		printf("ARCO GIA' PRESENTE\n");
		return e;
	}
	return e;
}

void inizializza_matrice(int A[MMAX][MMAX], int n){
	int i, j;
	for(i=0; i<n; i++)
		for(j=0; j<n; j++)
			A[i][j]=0;
}

void stampa_matrice(int A[MMAX][MMAX], int n){
	int i,j,t;
	for(i=0; i<n; i++){
		printf("NODI ADIACENTI A %d",i);
		printf("\n");
		t=0;
			for(j=0; j<n; j++){
				if(A[i][j]!=0){
					printf("NODO %d",j);
					printf(" CON PESO ");
					printf("%d",A[i][j]);
					printf("\n");
					t=1;
				}
			}
		if(t==0)
			printf("NESSUN NODO ADIACENTE\n");
		}
}

void aggiungi_arco_mat(int A[MMAX][MMAX],int u,int v, int peso){
	if(u!=v&&u>=0&&v>=0)
	A[u][v]=peso;
	else
	printf("FORNTI NODI UGUALI O CON VALORE ERRATO\n");
}

int unione_matrici(int U[MMAX][MMAX],int A[MMAX][MMAX], int B[MMAX][MMAX], int n1, int n2){
	int stp, i, j, G;
	if(n1>n2){
		inizializza_matrice(U,n1);
		stp=n2;
		G=n1;
		for(i=0;i<n2;i++)
			for(j=n2;j<n1;j++)
			U[i][j]=A[i][j];
		for(i=n2;i<n1;i++)
			for(j=0;j<n1;j++)
			U[i][j]=A[i][j];
	}
	else{
		inizializza_matrice(U,n2);
		stp=n1;
		G=n2;
		for(i=0;i<n1;i++)
			for(j=n1;j<n2;j++)
			U[i][j]=B[i][j];
		for(i=n1;i<n2;i++)
			for(j=0;j<n2;j++)
			U[i][j]=B[i][j];
	}
	for(i=0; i<stp; i++)
		for(j=0; j<stp; j++)
			U[i][j]=A[i][j]+B[i][j];
	return G;
}
