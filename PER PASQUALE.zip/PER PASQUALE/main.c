#include "grafi.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	/*int n, k1, k2, i;
	struct grafo* G;
	printf("INSERISCI IL NUMERO DI VERTICI: ");
	scanf("%d",&n);
	G=crea_grafo(n);
	for(i=0; i<5; i++){
		printf("INSERISCI CHIAVE VERTICE 1: ");
		scanf("%d",&k1);
		printf("INSERISCI CHIAVE VERTICE 2: ");
		scanf("%d",&k2);
		aggiunta_arco(G,k1,k2);
	}
	stampa_grafo(G);*/
	int M[MMAX][MMAX],M2[MMAX][MMAX],U[MMAX][MMAX],n,m,k1,k2,p,i,g;
	printf("INSERIRE NUMERO DI NODI GRAFO 1: ");
	scanf("%d",&n);
	inizializza_matrice(M,n);
	for(i=0; i<3; i++){
		printf("INSERISCI NODO 1: ");
		scanf("%d",&k1);
		printf("INSERISCI NODO 2: ");
		scanf("%d",&k2);
		printf("INSERISCI PESO ARCO: ");
		scanf("%d",&p);
		aggiungi_arco_mat(M,k1,k2,p);
	}
	printf("INSERIRE NUMERO DI NODI GRAFO 2: ");
	scanf("%d",&m);
	inizializza_matrice(M2,n);
	for(i=0; i<3; i++){
		printf("INSERISCI NODO 1: ");
		scanf("%d",&k1);
		printf("INSERISCI NODO 2: ");
		scanf("%d",&k2);
		printf("INSERISCI PESO ARCO: ");
		scanf("%d",&p);
		aggiungi_arco_mat(M2,k1,k2,p);
	}
	g=unione_matrici(U,M,M2,n,m);
	stampa_matrice(U,g);
	return 0;
}
