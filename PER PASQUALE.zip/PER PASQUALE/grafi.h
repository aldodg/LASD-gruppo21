#include <stdio.h>
#include <stdlib.h>

#define MMAX 100

struct nodo{
	int key;
	int peso;
	struct nodo* next;
};

struct grafo{
	int nv;
	struct nodo** v;
};

//CON LISTA DI ADIACENZA

struct grafo* crea_grafo(int);
int empty_graph(struct grafo*);
void stampa_grafo(struct grafo*);
void aggiunta_arco(struct grafo*,int,int);

struct nodo* inserimento_in_coda(struct nodo*, int);

//CON MATRICE DI ADIACENZA

void inizializza_matrice(int [MMAX][MMAX],int);
void stampa_matrice(int [MMAX][MMAX],int);
void aggiungi_arco_mat(int [MMAX][MMAX],int,int,int);
int unione_matrici(int [MMAX][MMAX], int [MMAX][MMAX],int [MMAX][MMAX],int,int);
