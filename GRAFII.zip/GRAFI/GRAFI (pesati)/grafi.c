#include "grafi.h"

struct grafo* crea_grafo(int n){
	struct grafo* G; int i;
	G=(struct grafo*)malloc(sizeof(struct grafo));
	G->v=(struct nodo**)malloc(sizeof(struct nodo*)*n);
	G->nv=n;
	for(i=0;i<n;i++)
		G->v[i]=NULL;
	return G;
}

int empty_graph(struct grafo* G){
	return G==NULL;
}

void stampa_grafo(struct grafo* G){
	int ca=0, i; struct nodo* app;
	if(!empty_graph(G)){
		printf("IL GRAFO HA VERTICI %d", G->nv);
		printf("\n");
		for(i=0;i<G->nv;i++){
			printf("NODI ADIACENTI AL VERTICE %d", i);
			printf("\n");
			app=G->v[i];
			while(app!=NULL){
				printf("%d",app->key);
				printf("\n");
				ca++;
				app=app->next;
			}
		}
	}
	printf("IL GRAFO HA ARCHI %d", ca/2);
	printf("\n");
}

void aggiunta_arco(struct grafo* G,int u,int v){
	struct nodo* elem1, *elem2, *app;
	if(G!=NULL)
		if(u>=0&&v>=0&&u<G->nv&&v<G->nv&&u!=v){
			G->v[u]=inserimento_in_coda(G->v[u],v);
			G->v[v]=inserimento_in_coda(G->v[v],u);
		}
			
}

struct nodo* inserimento_in_coda(struct nodo* e, int key){
	if(e==NULL){
		struct nodo* elem;
		elem=(struct nodo*)malloc(sizeof(struct nodo));
		elem->key=key;
		elem->next=NULL;
		return elem;
	}
	if(e->key!=key)
	e->next=inserimento_in_coda(e->next,key);
	else{
		printf("ARCO GIA' PRESENTE\n");
		return e;
	}
	return e;
}
