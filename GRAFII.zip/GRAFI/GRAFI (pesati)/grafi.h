#include <stdio.h>
#include <stdlib.h>

struct nodo{
	int key;
	int peso;
	struct nodo* next;
};

struct grafo{
	int nv;
	struct nodo** v;
};

struct grafo* crea_grafo(int);
int empty_graph(struct grafo*);
void stampa_grafo(struct grafo*);
void aggiunta_arco(struct grafo*,int,int);

struct nodo* inserimento_in_coda(struct nodo*, int);
