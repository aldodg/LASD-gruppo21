#include "grafi.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int n, k1, k2, i;
	struct grafo* G;
	printf("INSERISCI IL NUMERO DI VERTICI: ");
	scanf("%d",&n);
	G=crea_grafo(n);
	for(i=0; i<5; i++){
		printf("INSERISCI CHIAVE VERTICE 1: ");
		scanf("%d",&k1);
		printf("INSERISCI CHIAVE VERTICE 2: ");
		scanf("%d",&k2);
		aggiunta_arco(G,k1,k2);
	}
	stampa_grafo(G);
	return 0;
}
