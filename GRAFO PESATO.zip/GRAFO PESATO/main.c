#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "grafo.h"
#include "lettoreinput.h"

int main(int argc, const char * argv[])
{


    int scelta = -1, esci = 0;
  int part,arr, peso = 0;
  grafo *g;

  //if(!grafoVuoto(g)){

    while(esci == 0){

      do{
        printf("Seleziona operazione\n1 = aggiungiArco\n2 = rimuoviArco\n3 = esci\n");
        getPositive(&scelta);
      }while(scelta < 1 || scelta > 3);


      if(scelta == 1 || scelta == 2){
        do{
          printf("Inserire il vertice di partenza (max %d): ", (g->n_vertici)-1);
        }while(!getPositive(&part));

        do{
          printf("Inserire il vertice di arrivo (max %d): ", (g->n_vertici)-1);
        }while(!getPositive(&arr));

        if(g->pesato == 1 && scelta == 1){  //se l'operazione � di aggiunta e il grafo � pesato, allora viene preso da tastiera il peso.

          do{
            printf("Inserire il peso dell'arco: ");
          }while(!getPositive(&peso));

        }
      }
      printf("\n");

      switch(scelta){
        case 1:
          aggiungiArcoPesato(g, part, arr, peso);
          break;
        case 2:
          rimuoviArco(g, part, arr);
          break;
        case 3:
          esci = 1;
          break;
      }


}
return 0;
}
